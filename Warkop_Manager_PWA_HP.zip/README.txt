Warkop Manager PWA
Versi HP untuk dicoba tanpa Android Studio.
Cara termudah: buka index.html melalui browser yang mendukung file lokal. Untuk fitur instal sebagai aplikasi/PWA penuh, file harus disajikan lewat HTTPS/localhost.
Data tersimpan di localStorage browser.
